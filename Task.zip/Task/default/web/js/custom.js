require(['jquery', 'jquery/ui'], function($){      
	$(".page-footer .form.subscribe").submit(function(){
	    alert("This is just a test");
	    return false
	});
});